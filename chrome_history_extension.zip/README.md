# chrome_history_extension
A chrome extension that helps you visualize your Google Chrome browsing history
